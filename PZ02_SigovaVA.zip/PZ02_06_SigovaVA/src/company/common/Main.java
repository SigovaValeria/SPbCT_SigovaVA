package company.common;

public class Main {

    public static void main(String[] args) {
        long  i = 3422222;
        String str = Long.toString(i);
        System.out.println("Преобразование числа в строку: long to string");
        System.out.println(str);

    }
}
