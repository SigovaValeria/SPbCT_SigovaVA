package company.common;

public class Main {

    public static void main(String[] args) {
        double  i = 32.4e10;
        String str = Double.toString(i);
        System.out.println("Преобразование числа в строку: double to string");
        System.out.println(str);

    }
}
