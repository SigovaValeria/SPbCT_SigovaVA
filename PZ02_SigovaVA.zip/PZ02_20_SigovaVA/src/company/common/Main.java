package company.common;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        Point p1=new Point(2,3);
        Point p2=p1;
        Point p3=new Point(2,3);
        System.out.println(p1==p2);
        System.out.println(p1==p3);
    }
}
