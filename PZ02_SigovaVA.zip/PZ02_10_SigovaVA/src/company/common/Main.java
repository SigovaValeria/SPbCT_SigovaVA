package company.common;

public class Main {

    public static void main(String[] args) {
        byte x=-128;
        System.out.print(-x);

        byte y=127;
        System.out.print(++y);
    }
}
