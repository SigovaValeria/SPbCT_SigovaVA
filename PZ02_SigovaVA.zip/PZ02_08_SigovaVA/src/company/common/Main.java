package company.common;

public class Main {

    public static void main(String[] args) {
        System.out.println("int to long");
        int i = 2015;
        long l = (long) (i);
        System.out.println(l);
        System.out.println(" ");

        System.out.println("int to float");
        int e = 2015;
        float f = (float) (e);
        System.out.println(f);
        System.out.println(" ");

        System.out.println("long to int");
        long z = 214748364;
        int d = (int) z;
        System.out.println(d);
        System.out.println(" ");

        System.out.println("double to int");
        double a = 3.14;
        int u = (int) a;
        System.out.println(u);
        System.out.println(" ");

    }
}
