package company.common;

public class Main {

    public static void main(String[] args) {
        String s = "abc";
        Class cl=s.getClass();
        System.out.println(cl.getName());
    }
}
