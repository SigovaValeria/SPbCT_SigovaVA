package company.common;

public class Main {

    public static void main(String[] args) {
        int i = 35;
        String str = Integer.toString(i);
        System.out.println("Преобразование числа в строку: int to string");
        System.out.println(str);

    }
}
