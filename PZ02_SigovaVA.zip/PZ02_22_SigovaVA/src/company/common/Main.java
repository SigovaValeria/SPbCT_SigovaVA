package company.common;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        Point p1=new Point(2,3);
        Point p2=new Point(2,3);
        System.out.print(p1.equals(p2));
    }
}
