package company.common;

public class Main {

    public static void main(String[] args) {
        int x=1;
        System.out.print("x="+x);

    }
}
