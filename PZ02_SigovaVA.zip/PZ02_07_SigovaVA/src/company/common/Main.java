package company.common;

public class Main {

    public static void main(String[] args) {
        float  i = 3.46f;
        String str = Float.toString(i);
        System.out.println("Преобразование числа в строку: float to string");
        System.out.println(str);

    }
}
