package company.common;

public class Main {

    public static void main(String[] args) {
        int x=3;
        int y=5;
        System.out.println(x/y);
        System.out.println((double)x/y);
        System.out.println(1.0*x/y);
    }
}
