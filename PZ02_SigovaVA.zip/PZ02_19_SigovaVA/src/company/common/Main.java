package company.common;

public class Main {

    public static void main(String[] args) {
        long l=111111111111L;
        float f = l;
        l = (long) f;
        System.out.print(l);
    }
}
