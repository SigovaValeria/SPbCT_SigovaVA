package com.company;

public class Program {

    public static void main(String[] args) {

        Day day = Day.FRIDAY;
        System.out.println("День недели: " + day);

    }
    enum Day{

        MONDAY,
        TUESDAY,
        WEDNESDAY,
        THURSDAY,
        FRIDAY,
        SATURDAY,
        SUNDAY
    }

}

