package company.common;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        String k = console.nextLine();
        switch (k) {
            case ("Воскресенье"):
                System.out.println("0");
                break;
            case ("Понедельник"):
                System.out.println("1");
                break;
            case ("Вторник"):
                System.out.println("2");
                break;
            case ("Среда"):
                System.out.println("3");
                break;
            case ("Четверг"):
                System.out.println("4");
                break;
            case ("Пятница"):
                System.out.println("5");
                break;
            case ("Суббота"):
                System.out.println("6");
                break;
            default:
                System.out.println("Ошибка! Такого дня недели нет!");
                break;
        }
    }
}