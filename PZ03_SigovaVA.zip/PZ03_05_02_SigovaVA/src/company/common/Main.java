package company.common;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        double x = console.nextDouble();
        double a = 0.55;
        double b = 4.31;
        double y = 0;

        if(x<0.5)
            y = Math.sin(b*x) + 1;

        if(x>=0.5 && x<=2.5)
            y = 1/Math.tan(x);

        if(x>2.5)
            y = a*Math.pow(x,3);

        System.out.println("y = "+y);
    }
}
