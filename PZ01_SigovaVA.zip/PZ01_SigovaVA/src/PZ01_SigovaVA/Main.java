package PZ01_SigovaVA;

class Variables {

    public static void main(String args []) {

        double a = 3;

        double b = 4;

        double c;

        c = Math.sqrt(a* a + b* b);

        System.out.println("c = "+ c);

    } }
