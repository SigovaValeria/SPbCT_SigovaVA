package com.example.cw02_04_19;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        int n = 6;
        double y = 0;
        double x = 0.33;
        for(int i = 1; i <= n; i++) {
            y = y + Math.cos(i*x);
        }
        super.onCreate(savedInstanceState);
        TextView textView = new TextView(this);
        textView.setTextSize(30);
        textView.setPadding(16, 16, 16, 16);
        textView.setText("Примерное значение y = "+ (int)y);
        setContentView(textView);
    }
}