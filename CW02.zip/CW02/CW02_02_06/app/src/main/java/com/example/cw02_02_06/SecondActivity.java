package com.example.cw02_02_06;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView textView1 = new TextView(this);
        TextView textView2 = new TextView(this);
        textView1.setTextSize(30);
        textView1.setPadding(16, 16, 16, 16);
        textView2.setTextSize(30);
        textView2.setPadding(16, 50, 16, 16);

        Bundle arguments = getIntent().getExtras();

        if(arguments!=null){
            double name = arguments.getDouble("name");
            double company = arguments.getDouble("company");
            double candy1 = 0.3*name;
            double cookies1 = 0.4*company;
            double price1 = candy1 + cookies1;
            double candy2 = (1.8*name)*3;
            double cookies2 = (2*company)*3;
            double price2 = candy2 + cookies2;
            String priceA = Double.toString(price1);
            String priceB = Double.toString(price2);
            textView1.setText("a) Стоимость одной покупки из 300 г конфет и 400 г печенья: " + priceA + "\n");
            textView2.setText("б) Стоимость трех покупок, каждая из 2 кг печенья и 1 кг 800 г конфет: " + priceB);
        }
        setContentView(textView1);
        setContentView(textView2);
    }
}
