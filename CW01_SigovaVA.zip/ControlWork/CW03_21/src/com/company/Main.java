package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner one = new Scanner(System.in);
        System.out.println("Введите первое целое число:");
        int x1 = one.nextInt();

        Scanner two = new Scanner(System.in);
        System.out.println("Введите второе целое число:");
        int x2 = two.nextInt();

        Scanner three = new Scanner(System.in);
        System.out.println("Введите третье целое число:");
        int x3 = three.nextInt();

        if((x1 < 5 && x2 < 5) || (x2 < 5 && x3 < 5) || (x3 < 5 && x1 < 5))
            System.out.println("yes");
        else
            System.out.println("no");
    }
}
