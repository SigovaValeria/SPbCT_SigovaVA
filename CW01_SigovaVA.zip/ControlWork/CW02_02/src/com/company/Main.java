package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите любое число:  ");
        double x = scanner.nextDouble();

        System.out.println("Квадрат Вашего числа = " + x*x + "\n" + "Куб Вашего числа = " + x*x*x);
    }
}
