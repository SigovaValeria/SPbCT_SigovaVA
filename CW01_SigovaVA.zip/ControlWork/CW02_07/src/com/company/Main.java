package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner1 = new Scanner(System.in);
        System.out.println("Введите время в минутах :)");
        double minutes = scanner1.nextDouble();

        Scanner scanner2 = new Scanner(System.in);
        System.out.println("Введите расстояние в километрах :)");
        double km = scanner2.nextDouble();

        double seconds = minutes*60;
        double m = km*1000;
        double speed = m/seconds;
        System.out.println("Скорость = " + speed + " м/с");
    }
}
