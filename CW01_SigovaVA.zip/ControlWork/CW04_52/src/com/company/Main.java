package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите число k:");
        int k = sc.nextInt();

        int x = 0;
        int n = 12;
        for(int i = 0; i < n; i++) {
            x = x + i;
            System.out.println((i+1) + ". " + x);
            if(x != k)
                System.out.println("no");
            else
                System.out.println("yes");
        }
    }
}
