package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите номер месяца :з");
        int x = scanner.nextInt();

        switch (x) {
            case 12:
                System.out.println("Месяц - Декабрь. Время года - Зима.");
                break;
            case 1:
                System.out.println("Месяц - Январь. Время года - Зима.");
                break;
            case 2:
                System.out.println("Месяц - Февраль. Время года - Зима.");
                break;
            case 3:
                System.out.println("Месяц - Март. Время года - Весна.");
                break;
            case 4:
                System.out.println("Месяц - Апрель. Время года - Весна.");
                break;
            case 5:
                System.out.println("Месяц - Май. Время года - Весна.");
                break;
            case 6:
                System.out.println("Месяц - Июнь. Время года - Лето.");
                break;
            case 7:
                System.out.println("Месяц - Июль. Время года - Лето.");
                break;
            case 8:
                System.out.println("Месяц - Август. Время года - Лето.");
                break;
            case 9:
                System.out.println("Месяц - Сентябрь. Время года - Осень.");
                break;
            case 10:
                System.out.println("Месяц - Октябрь. Время года - Осень.");
                break;
            case 11:
                System.out.println("Месяц - Ноябрь. Время года - Осень.");
                break;
        }
    }
}
