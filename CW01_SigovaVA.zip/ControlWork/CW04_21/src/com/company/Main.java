package com.company;

public class Main {

    public static void main(String[] args) {

        float x = 10; // расстояние в день
        int n = 9; // кол-во дней
        double summa_all = 10;
        double summa_7 = 10;
        for(int i = 2; i < 7; i++) {
            x = x + x/10;
            summa_7 = summa_7 + x;
        }
        x = 10;
        int day = 0;
        System.out.println("День 1" + " " + "Расстояние = " + x);
        for(int i = 0; i < n; i++) {
            x = x + x/10;
            summa_all = summa_all + x;
            System.out.println("День " + (i + 2) + " " + "Расстояние = " + x);
            if(summa_all > 70)
                day = i;
        }
        System.out.println("Суммарный путь за первые 7 дней тренировок = " + summa_7);
        System.out.println("Суммарный путь за все время тренировок = " + summa_all);
        System.out.println("На " + day + " день пробежек лыжнику стоит перестать тренироваться, иначе пробег будет превышать 80 км.");

    }
}
