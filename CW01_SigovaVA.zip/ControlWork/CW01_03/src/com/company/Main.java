package com.company;

public class Main {

    public static void main(String[] args) {
	System.out.println("0");
	System.out.println("00");
    System.out.println("000");
    System.out.println("0000");
    System.out.println("00000");
    }
}
